﻿using System;

namespace EFCore2Study.ConsoleApp.DBFirst
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");
        }
    }
}
