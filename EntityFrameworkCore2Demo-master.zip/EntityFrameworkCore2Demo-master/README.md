# EntityFrameworkCore2Demo
.NET Core控制台、ASP.NET Core程序使用EntityFrameworkCore 2.0示例，包括CodeFirst、DBFirst。详细文章介绍请看：http://www.cnblogs.com/stulzq/p/7717873.html
